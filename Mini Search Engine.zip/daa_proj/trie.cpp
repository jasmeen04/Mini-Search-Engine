#include "trie.h"

Trie::Trie() {
    root = new TrieNode();
}

void Trie::insert(const std::string& word, int documentId) {
    insertHelper(root, word, documentId);
}

void Trie::insertHelper(TrieNode* node, const std::string& word, int documentId) {
    for (char c : word) {
        if (node->children.find(c) == node->children.end()) {
            node->children[c] = new TrieNode();
        }
        node = node->children[c];
    }

    node->documentIds.push_back(documentId);
}

std::vector<int> Trie::search(const std::string& word) {
    TrieNode* node = root;

    for (char c : word) {
        if (node->children.find(c) == node->children.end()) {
            return std::vector<int>();  // Return empty vector if word not found
        }
        node = node->children[c];
    }

    return node->documentIds;
}
