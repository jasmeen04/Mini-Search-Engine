#ifndef SEARCH_ENGINE_H
#define SEARCH_ENGINE_H

#include <string>
#include <vector>
#include "trie.h"

class SearchEngine {
public:
    SearchEngine();

    void loadDocuments(const std::string& filePath);
    std::vector<std::string> search(const std::string& query);

private:
    Trie trie;
};

#endif  // SEARCH_ENGINE_H
