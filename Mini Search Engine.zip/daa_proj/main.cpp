#include <iostream>
#include <fstream>
#include <string>
#include "search_engine.h"

using namespace std;

int main() {
    SearchEngine searchEngine;
    searchEngine.loadDocuments("documents.txt");

    string query;
    cout << "Enter your query: ";
    getline(cin, query);

    vector<string> results = searchEngine.search(query);
    if (results.empty()) {
        cout << "No results found." << endl;
    } else {
        cout << "Search results:" << endl;
        for (const string& result : results) {
            cout << "- " << result << endl;
        }
    }

    return 0;
}
