#ifndef TRIE_H
#define TRIE_H

#include <string>
#include <vector>
#include <unordered_map>

class Trie {
public:
    Trie();
    void insert(const std::string& word, int documentId);
    std::vector<int> search(const std::string& word);

private:
    struct TrieNode {
        std::unordered_map<char, TrieNode*> children;
        std::vector<int> documentIds;
    };

    TrieNode* root;

    void insertHelper(TrieNode* node, const std::string& word, int documentId);
};

#endif  // TRIE_H
