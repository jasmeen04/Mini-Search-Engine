#include "search_engine.h"
#include <fstream>
#include <sstream>

SearchEngine::SearchEngine() {}

void SearchEngine::loadDocuments(const std::string& filePath) {
    std::ifstream file(filePath);
    std::string line;
    int documentId = 1;

    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string word;

        while (iss >> word) {
            trie.insert(word, documentId);
        }

        documentId++;
    }

    file.close();
}

std::vector<std::string> SearchEngine::search(const std::string& query) {
    std::vector<int> documentIds = trie.search(query);

    std::vector<std::string> results;
    for (int documentId : documentIds) {
        std::string result = "Document " + std::to_string(documentId);
        results.push_back(result);
    }

    return results;
}
